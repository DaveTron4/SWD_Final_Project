import React from 'react'

const FooterComponent = () => {
  // Render nothing to effectively remove the footer
  return null; 
}

export default FooterComponent